package br.com.frederykantunnes.projetochatcesar_androidavancado;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ContatoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<ContatoModel> mUsers;
    private List<ContatoModel> mUsersFiltered;

    public ContatoAdapter(Context context, ArrayList<ContatoModel> users) {
        this.context = context;
        mUsers = users;
        mUsersFiltered = users;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tx_principal, tx_secondary;
        public CircleImageView img;
        public ViewHolder(View itemView) {
            super(itemView);
            tx_principal =  itemView.findViewById(R.id.tvName);
            tx_secondary =  itemView.findViewById(R.id.tvLastMessage);
            img = itemView.findViewById(R.id.imgUser);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ContatoAdapter.ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_contact, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            ViewHolder vh = (ViewHolder) holder;
            vh.tx_principal.setText(mUsers.get(position).getFirstName()+" "+mUsers.get(position).getLastName());
            vh.tx_secondary.setText(mUsers.get(position).getEmail());
        }else{

        }
    }

    private void removerItem(int position) {
        mUsers.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mUsers.size());
    }

    @Override
    public int getItemCount() {
        return mUsers != null ? mUsers.size() : 0;
    }

    public void updateList(ContatoModel user) {
        insertItem(user);
    }

    private void insertItem(ContatoModel contatoModel) {
        mUsers.add(contatoModel);
        notifyItemInserted(getItemCount());
    }
}
