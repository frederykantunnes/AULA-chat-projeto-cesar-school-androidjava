package br.com.frederykantunnes.projetochatcesar_androidavancado;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class Chats extends AppCompatActivity {
    ContatoAdapter contatoAdapter;
    private ArrayList<ContatoModel> list;
    LinearLayoutManager layoutManager;
    private RecyclerView recyclerView;
    private ContatoAdapter mAdapter;
//    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chats);

        recyclerView = findViewById(R.id.recicle_list);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);




        list = new ArrayList<>();
        mAdapter = new ContatoAdapter(this, list);
        recyclerView.setAdapter(mAdapter);

        list.add(new ContatoModel(1,"frederykantunnes@gmail.com","Frederyk","Antunnes","imagem.jpg"));
        list.add(new ContatoModel(1,"frederykantunnes@gmail.com","Frederyk Sousa","Antunnes","imagem.jpg"));


//        mDatabase = FirebaseDatabase.getInstance().getReference();


        mAdapter.notifyDataSetChanged();


//        DocumentReference docRef = db.collection("users").document("zxy");
//        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
//            @Override
//            public void onSuccess(DocumentSnapshot documentSnapshot) {
//                ContatoModel city = documentSnapshot.toObject(ContatoModel.class);
//                Toast.makeText(Chats.this, city.getFirstName(), Toast.LENGTH_LONG).show();
//            }
//        });
        CircleImageView img = findViewById(R.id.imageProfile);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Chats.this, Perfil.class));
                finish();
            }
        });

    }

}
